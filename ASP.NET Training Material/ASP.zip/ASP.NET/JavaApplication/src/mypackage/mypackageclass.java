
package mypackage;

public class mypackageclass 
{
  public void mypackagemethod()
  {
      
  
  }
}
