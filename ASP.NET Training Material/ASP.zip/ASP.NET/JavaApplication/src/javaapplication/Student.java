package javaapplication;
public class Student
{
    public static void main(String[] args)
    {
      Student ajay=new Student();
      ajay.study();
      
    }
     public static void study()
     {
         System.out.println("I am studying");    
     }
}
