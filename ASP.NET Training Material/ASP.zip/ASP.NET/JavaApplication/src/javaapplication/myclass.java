
package javaapplication;

public class myclass
{
 void mymethod()
{
    
}
}
