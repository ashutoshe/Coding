
package javaapplication;
import java.util.*;
public class JavaApplication 
{
    public static void main(String[] args)
    {
            Scanner s=new Scanner(System.in);
         int a=s.nextInt();
           String str=s.next();
    }
}
