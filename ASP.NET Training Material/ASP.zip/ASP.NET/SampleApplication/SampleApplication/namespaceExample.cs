﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using n1;
using n1.n2;
namespace SampleApplication
{
    class namespaceExample
    {
        public static void Main()
        {
          
        }
    }
}
