﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SampleApplication
{
    class ifleseExample
    {
        public static void Main()
        {
            int  num1=10;
            if(num1>0)
            {

            }
            else
            {

            }
        }
    }
}
