﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SampleApplication
{
    interface i1
    {
        void m1();
    }
    class InterfaceExample
    {
        public void m1()
        {
        }
    }
}
