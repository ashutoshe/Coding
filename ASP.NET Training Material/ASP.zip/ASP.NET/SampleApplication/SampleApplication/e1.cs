﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace n1
{
    class e1
    {
        public void m1()
        {
        }
    }

    namespace n2
    {
        class e2
        {
            public void m2()
            {
            }
        }
    }
}
