﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SampleApplication
{
   abstract class Shape
    {
        public abstract void CalculateArea();
        public void mymethod()
        {

        }
    }

    class circle : Shape
    {
        public override void CalculateArea()
        {
            
        }


    }

    
}
