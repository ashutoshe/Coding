﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassLibrary1
{
    public class Class1
    {
        public void publicmethod123()
        {
        }
        void privatemethod123()
        {
        }

        protected void protectedmethod123()
        {
        }

        internal void internalmethod123()
        {
        }
    }
}
